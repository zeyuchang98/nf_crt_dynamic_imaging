"""Validate the approved saved intensity-resolution comparison without training."""
import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
from PIL import Image
import torch

from motion_static.evaluation.compare_training import load_model
from motion_static.evaluation.metrics import error_metrics
from motion_static.phantoms.data import coordinate_grid
from motion_static.training_monitor import fixed_mse


root = Path('/Users/zeyuchang/Research/nf_crt_dynamic_imaging')
group = root / 'motion_static/results/complex/low_rank_intensity_max64'
run = group / 'steps_32000'
baseline = root / 'motion_static/results/complex/low_rank_coarse_motion/steps_32000'
torch.set_num_threads(4)
report = json.loads((group / 'verification.json').read_text())
summary = json.loads((run / 'summary.json').read_text())
config = summary['config']
model, checkpoint = load_model(run / 'model.pt')
assert checkpoint['step'] == config['steps'] == 32000
final = torch.load(run / 'checkpoints/step_032000.pt', map_location='cpu', weights_only=True)
assert final['step'] == checkpoint['step']
assert all(torch.equal(value, final['state_dict'][name]) for name, value in checkpoint['state_dict'].items())
report['final_checkpoint_equals_intermediate'] = True
report['final_step'] = checkpoint['step']

base_config = json.loads((baseline / 'config.json').read_text())
fixed_keys = ['phantom', 'model', 'size', 'frames', 'cycles', 'seed', 'steps', 'batch_size',
              'threads', 'mlp_lr', 'hash_lr', 'rank', 'head_width', 'temporal_width',
              'motion_encoding', 'checkpoint_steps', 'monitor_samples', 'monitor_seed',
              'log_interval', 'coordinate_bounds', 'reference_time', 'loss', 'device', 'scheduler']
assert all(config[key] == base_config[key] for key in fixed_keys)
assert config['encoding']['max_resolution'] == 64
assert base_config['encoding']['max_resolution'] == 128
assert all(config['encoding'][k] == base_config['encoding'][k]
           for k in config['encoding'] if k != 'max_resolution')
assert model.intensity.encoding.resolutions.tolist() == [8, 10, 14, 19, 26, 35, 47, 64]
report['saved_settings_match_baseline'] = fixed_keys
report['motion_resolutions'] = model.motion.field.encoding.resolutions.tolist()
report['motion_parameters'] = sum(p.numel() for p in model.motion.parameters())
report['intensity_parameters'] = sum(p.numel() for p in model.intensity.parameters())
assert report['motion_parameters'] == 174474
assert sum(p.numel() for p in model.parameters()) == report['total_parameters'] == summary['parameters']

source_hashes = config['code_provenance']['source_sha256']
with ZipFile(run / 'source.zip') as archive:
    assert set(archive.namelist()) == set(source_hashes)
    for name, expected in source_hashes.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected, name
report['source_snapshot_files_verified'] = len(source_hashes)
report['training_source_git_commit'] = config['code_provenance']['git_commit']

x = np.linspace(*config['coordinate_bounds'][0], config['size'])
y = np.linspace(*config['coordinate_bounds'][1], config['size'])
reference = coordinate_grid(x, y, np.array([config['reference_time']]))
with torch.no_grad():
    reference_motion = model.motion(torch.tensor(reference, dtype=torch.float32))
assert reference_motion.abs().max().item() == 0
report['reference_point_count'] = len(reference)
report['reference_motion_max_abs'] = 0.0

with np.load(run / 'arrays/predictions.npz') as arrays:
    train_times = arrays['training_t']
    midpoint_times = arrays['midpoint_t']
    assert not np.isclose(train_times[:, None], midpoint_times[None, :], rtol=0, atol=1e-10).any()
    coordinates = coordinate_grid(x, y, midpoint_times)
    rng = np.random.default_rng(2026)
    chosen = rng.choice(len(coordinates), 511, replace=False)
    query = torch.tensor(coordinates[chosen], dtype=torch.float32, requires_grad=True)
    output = model(query)
    stored = arrays['midpoint_image'].reshape(-1)[chosen]
    difference = float(np.max(np.abs(output.detach().numpy() - stored)))
    assert difference < 1e-6
    gradient = torch.autograd.grad(output.sum(), query)[0]
    assert torch.isfinite(gradient).all() and gradient[:, :2].abs().max() > 0
report.update(training_midpoint_times_disjoint=True, saved_prediction_samples=511,
              saved_prediction_max_abs_difference=difference,
              coordinate_gradients_finite=True, spatial_coordinate_gradients_nonzero=True)

with np.load(baseline / 'monitor_samples.npz') as old, np.load(run / 'monitor_samples.npz') as new:
    assert old.files == new.files
    assert all(np.array_equal(old[key], new[key]) for key in old.files)
    monitoring = {key: new[key] for key in new.files}
report['fixed_monitoring_indices_identical'] = True
with (run / 'loss.csv').open() as stream:
    rows = list(csv.DictReader(stream))
assert [int(row['step']) for row in rows] == [0, 1, *range(500, 32001, 500)]
assert all(float(row['temporal_l2']) == 0 and row['batch_mse'] == row['total_loss'] for row in rows[1:])
assert all(float(rows[-1][key]) == 0 for key in rows[-1] if key.startswith('next_lr_'))
report.update(loss_history_rows=len(rows), image_mse_only_verified=True, final_learning_rates_zero=True)

with np.load(run / 'arrays/image.npz') as image:
    for split, prefix, times, history_key in [('training', '', train_times, 'fixed_training_mse'),
                                            ('validation', 'midpoint_', midpoint_times, 'fixed_validation_mse')]:
        indices = monitoring[f'{split}_indices']
        points = coordinate_grid(x, y, times)[indices]
        values = image[prefix + 'truth'].reshape(-1)[indices]
        mse = fixed_mse(model, torch.tensor(points, dtype=torch.float32), torch.tensor(values, dtype=torch.float32))
        assert np.isclose(mse, float(rows[-1][history_key]), rtol=1e-7, atol=1e-12)
        report[history_key + '_recomputed'] = mse
    for prefix, label in [('', 'training_grid'), ('midpoint_', 'unseen_time_midpoints')]:
        recomputed = error_metrics(image[prefix + 'truth'], image[prefix + 'prediction'], data_range=1)['rrmse']
        assert np.isclose(recomputed, summary['image'][label]['rrmse'], rtol=1e-12)
with np.load(run / 'arrays/reference_intensity.npz') as intensity:
    for prefix, label in [('', 'training_grid'), ('midpoint_', 'unseen_time_midpoints')]:
        recomputed = error_metrics(intensity[prefix + 'truth'], intensity[prefix + 'prediction'], data_range=1)['rrmse']
        assert np.isclose(recomputed, summary['reference_intensity'][label]['rrmse'], rtol=1e-12)
report['saved_image_and_intensity_rrmse_recomputed'] = True
rank = summary['intensity_rank']
assert rank['rank_limit'] == 2
report['rank_relative_tails'] = {key: value['relative_frobenius_tail_after_rank'] for key, value in rank['splits'].items()}
assert max(report['rank_relative_tails'].values()) < 1e-6

report['gifs'] = {}
for name in ['image.gif', 'reference_intensity.gif', 'motion_only.gif', 'motion_effect.gif']:
    with Image.open(run / 'plots' / name) as animation:
        assert animation.n_frames == 378 and animation.size == (864, 408)
        assert animation.info['duration'] == 90
        entry = dict(frames=animation.n_frames, size=list(animation.size), duration_ms=animation.info['duration'])
        if name == 'motion_effect.gif':
            distinct = set()
            for frame in range(animation.n_frames):
                animation.seek(frame)
                panel = animation.convert('RGB').crop((0, 76, 288, 364))
                distinct.add(hashlib.sha256(panel.tobytes()).hexdigest())
            entry['unique_truth_panel_images'] = len(distinct)
            assert len(distinct) > 1
        report['gifs'][name] = entry
comparison = json.loads((group / 'comparison.json').read_text())
assert comparison['comparison_type'] == 'intensity_spatial_grid'
assert comparison['labels'] == ['intensity_max128', 'intensity_max64']
for name, expected in comparison['source_sha256'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected
assert comparison['analysis_source_sha256'] == hashlib.sha256((root / 'motion_static/evaluation/compare_training.py').read_bytes()).hexdigest()
report['comparison_checkpoint_and_source_hashes_verified'] = True
report['comparison_pipeline_smoke_passed'] = True
report['verification_source_archive'] = 'validation_sources.zip'
report['verification_script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
report.update(status='complete', training_and_evaluation_complete=True)
(group / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
