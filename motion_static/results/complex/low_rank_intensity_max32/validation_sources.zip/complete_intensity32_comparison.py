"""Complete the approved max-32 comparison after the existing training job finishes."""
import datetime
import json
from pathlib import Path
import subprocess
import time
from zipfile import ZipFile, ZIP_DEFLATED

root = Path('/Users/zeyuchang/Research/nf_crt_dynamic_imaging')
group = root / 'motion_static/results/complex/low_rank_intensity_max32'
python = '/Users/zeyuchang/miniconda3/envs/nf-crt/bin/python'
runs = [root / 'motion_static/results/complex' / name / 'steps_32000'
        for name in ['low_rank_coarse_motion', 'low_rank_intensity_max64', 'low_rank_intensity_max32']]
status = {'phase': 'waiting_for_training', 'exit_status': None, 'commands': []}
def save_status():
    status['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (group / 'pipeline_status.json').write_text(json.dumps(status, indent=2) + '\n')
save_status()
try:
    started = time.monotonic()
    while True:
        log = (group / 'training.log').read_text()
        if 'Saved results:' in log:
            break
        if 'Traceback (most recent call last)' in log:
            raise RuntimeError('Training failed; see preserved training.log')
        if time.monotonic() - started > 10800:
            raise RuntimeError('Timed out waiting for training completion')
        time.sleep(5)
    jobs = [
        ('checkpoint_comparison', [python, '-u', '-m', 'motion_static.evaluation.compare_training',
            *map(str, runs), '--out', str(group), '--vary-intensity-grid',
            '--labels', 'intensity_max128', 'intensity_max64', 'intensity_max32'], 'comparison.log'),
        ('gif_comparison', [python, '-u', '-m', 'motion_static.evaluation.compare_gifs',
            *map(str, runs), '--out', str(group)], 'gif_comparison.log'),
        ('result_validation', [python, '-u', '/tmp/verify_intensity32_result.py'], 'result_validation.log')
    ]
    for phase, command, log_name in jobs:
        status['phase'] = phase
        status['commands'].append({'phase': phase, 'command': command})
        save_status()
        with (group / log_name).open('w') as log:
            result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
        status['commands'][-1]['exit_status'] = result.returncode
        save_status()
        if result.returncode:
            raise RuntimeError(f'{phase} failed with exit status {result.returncode}; see {log_name}')
    with ZipFile(group / 'validation_sources.zip', 'w', ZIP_DEFLATED) as archive:
        for name in ['verify_intensity32_result.py', 'complete_intensity32_comparison.py']:
            archive.write(Path('/tmp') / name, name)
    status.update(phase='complete', exit_status=0)
except Exception as error:
    status.update(phase='failed', exit_status=1, error=str(error))
    raise
finally:
    save_status()
