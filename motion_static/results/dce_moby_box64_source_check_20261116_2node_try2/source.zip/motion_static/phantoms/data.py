"""Generate either phantom with the same axes, labels, and train/midpoint split."""
import argparse
import copy
import math
from pathlib import Path

import numpy as np
import torch

from . import simple, complex


DEFAULT_PHANTOM = "complex"
DEFAULT_SAMPLING = {
    "complex": {"frames": 379, "cycles": 3},
    "simple": {"frames": 64, "cycles": 1},
}


def get_phantom(name):
    return {"simple": simple, "complex": complex}[name]


def coordinate_grid(x, y, t, z=None):
    """Flatten a (y,x,t) volume into rows of (x,y,t), or a (y,x,z,t) volume into rows of (x,y,z,t)."""
    if z is None:
        yy, xx, tt = np.meshgrid(y, x, t, indexing="ij")
        return np.stack((xx, yy, tt), axis=-1).reshape(-1, 3)
    yy, xx, zz, tt = np.meshgrid(y, x, z, t, indexing="ij")
    return np.stack((xx, yy, zz, tt), axis=-1).reshape(-1, 4)


def entry_coordinates(entry, frames=slice(None)):
    """coordinate_grid rows of a data entry (x, y, optional z, t), for the selected frames."""
    return coordinate_grid(entry["x"], entry["y"], entry["t"][frames], entry.get("z"))


class CoordinateGrid:
    """The rows of coordinate_grid(x, y, t, z), computed from flat row indices on demand.

    Only the axes are stored, so a large 3D space-time grid never exists as an (N, 4)
    array. Rows follow coordinate_grid: volume axes (y, x[, z], t), the last fastest;
    values are the float32 axis values, as torch.as_tensor(coordinate_grid(...), float32).
    """

    def __init__(self, x, y, t, z=None):
        volume_axes = [y, x] + ([] if z is None else [z]) + [t]
        self.axes = [torch.as_tensor(np.asarray(axis), dtype=torch.float32) for axis in volume_axes]
        self.shape = tuple(len(axis) for axis in self.axes)

    def __len__(self):
        return math.prod(self.shape)

    def to(self, device):
        moved = copy.copy(self)
        moved.axes = [axis.to(device) for axis in self.axes]
        return moved

    def __getitem__(self, indices):
        remaining = torch.as_tensor(indices, dtype=torch.long, device=self.axes[0].device)
        positions = [None] * len(self.shape)
        for axis in reversed(range(len(self.shape))):  # unravel, last axis fastest
            positions[axis] = remaining % self.shape[axis]
            remaining = remaining // self.shape[axis]
        values = [axis[position] for axis, position in zip(self.axes, positions)]
        return torch.stack([values[1], values[0], *values[2:]], dim=-1)  # columns x, y[, z], t


def coordinate_rows(entry):
    """Rows (x, y[, z], t) of an entry's whole grid, in entry["truth"].reshape(-1) order.

    2D grids give the coordinate_grid array; 3D grids give a CoordinateGrid, whose rows
    are computed on demand because the (N, 4) array may not fit in memory.
    """
    if "z" in entry:
        return CoordinateGrid(entry["x"], entry["y"], entry["t"], entry["z"])
    return coordinate_grid(entry["x"], entry["y"], entry["t"])


def sample(name, size, times, time_bounds=(-0.5, 0.5)):
    if size < 16:
        raise ValueError("Use at least 16 pixels per side")
    t = np.asarray(times, dtype=float)
    if t.ndim != 1 or not t.size or not np.isfinite(t).all() or np.any(np.diff(t) <= 0):
        raise ValueError("Times must be finite, nonempty, and strictly increasing")
    bounds = np.asarray(time_bounds, dtype=float)
    if bounds.shape != (2,) or not np.isfinite(bounds).all() or bounds[1] <= bounds[0]:
        raise ValueError("Time bounds must be finite and increasing")
    if t.min() < bounds[0] or t.max() > bounds[1]:
        raise ValueError(f"Times must lie in {tuple(bounds)}")
    phantom = get_phantom(name)
    x = y = np.linspace(-0.5, 0.5, size)
    xyt = coordinate_grid(x, y, t)
    u = phantom.motion(xyt)
    warped = xyt.copy()
    warped[:, :2] += u
    shape = (size, size, len(t))
    truth = phantom.reference_intensity(warped, size).reshape(shape).astype(np.float32)
    reference_intensity = phantom.reference_intensity(xyt, size).reshape(shape).astype(np.float32)
    return dict(x=x, y=y, t=t, truth=truth, reference_intensity=reference_intensity,
                u_true=u.reshape(*shape, 2).astype(np.float32), foreground_mask=truth > 0)


def make_pair(name=DEFAULT_PHANTOM, size=64, frames=None, cycles=None):
    """Use the approved phantom defaults unless sampling is explicitly supplied."""
    defaults = DEFAULT_SAMPLING[name]
    frames = defaults["frames"] if frames is None else frames
    cycles = defaults["cycles"] if cycles is None else cycles
    if frames < 2:
        raise ValueError("Use at least two training frames")
    if not isinstance(cycles, int) or isinstance(cycles, bool) or cycles < 1:
        raise ValueError("Use a positive integer number of complete cycles")
    # The joint period of both existing phantoms is one input-time unit.
    # Extend observation time; do not rescale the dynamics or wrap network inputs.
    bounds = (-0.5, cycles - 0.5)
    times = np.linspace(*bounds, frames)
    return {"training": sample(name, size, times, bounds),
            "midpoint": sample(name, size, (times[:-1] + times[1:]) / 2, bounds)}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phantom", choices=("simple", "complex"), default=DEFAULT_PHANTOM,
                        help="Phantom to generate (default: complex)")
    parser.add_argument("--out", type=Path)
    parser.add_argument("--frames", type=int, help="Training frames (complex: 379; simple: 64)")
    parser.add_argument("--cycles", type=int, help="Complete cycles (complex: 3; simple: 1)")
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    out = args.out or root / "results" / args.phantom / "phantom"
    out.mkdir(parents=True, exist_ok=False)
    data = make_pair(args.phantom, frames=args.frames, cycles=args.cycles)
    for split, arrays in data.items():
        np.savez_compressed(out / f"{split}.npz", **arrays)
    from ..evaluation.plots import save_phantom
    save_phantom(out, data["training"], args.phantom)
    print(out)


if __name__ == "__main__":
    main()
